module.exports = {
	consumer_key: "Mtvgfpj2A5il8rTc15SqydEgo",
	consumer_secret: "VrT5zSD60jA5fCeaasM1T5IVGUQHyov7oUPpMPBo8kRHzWZU6J",
	access_token_key: "831738234275246081-wtwljnhBlwdryJ8LgKUqy7OxFZgeo0F",
	access_token_secret: "HokZflpIoLGRls2OAihUALzEZw6FsOhzWqxYt3cuUznUz"
};
